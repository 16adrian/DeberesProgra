import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//Autor: Adrian Morales Quilumba
public class Ventana {
    private JPanel principal;
    private JTextField txtNombre;
    private JTextField txtRendimiento;
    private JComboBox cboPosicion;
    private JButton btnRegistrar;
    private JTextArea txtListado;
    private JSpinner spCodigo;
    private JButton btnBuscar;
    private JButton btnMostrar;
    private JButton btnEliminar;
    private JButton btnEditar;
    private Equipo eq1 = new Equipo();
    public Ventana()
    {
        btnRegistrar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e)
            {
                //algoritmo solo para registrar jugador
                String nombre = txtNombre.getText();
                float ren = Float.parseFloat(txtRendimiento.getText());
                String pos = cboPosicion.getSelectedItem().toString();
                Jugador n = new Jugador(-1, nombre, ren, pos);
                eq1.agregarJugador(n);
                //para que se muestre, cada que agregamos 1 se va a refrescar y listar todos los jugadores
                txtListado.setText(eq1.listarTodos());
            }
        });
        //primero crear variable codigo
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int codigo = Integer.parseInt(spCodigo.getValue().toString());
                try
                {
                    Jugador j = eq1.buscarJugador(codigo);
                    //este jugador se lista con sus atributos en el text area
                    txtListado.setText(j.toString());
                }catch (Exception ex)
                        //si se muestra un error lo vamos a capturar y mostrar al usuario
                {
                    JOptionPane.showMessageDialog(null, ex.getMessage());

                }

            }
        });
        btnMostrar.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //mostrar otra vez todos los elmeentos
                txtListado.setText(eq1.listarTodos());
            }
        });
        btnEliminar.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

                int codigo = Integer.parseInt(spCodigo.getValue().toString());
                try {
                    //aqui llamo al metodo de eliminar jugador
                    eq1.eliminarJugador(codigo);
                    //aqui seteo la lista del texto con la lista actualizada
                    txtListado.setText(eq1.listarTodos());
                    JOptionPane.showMessageDialog(null, "Jugador eliminado correctamente.");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage()); //salta el error si es que hay con el jopton
                }
            }
        });

        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int codigo = Integer.parseInt(Ventana.this.spCodigo.getValue().toString());
                //aqui obtengo el nombre, rendimiento y posicion de los botones
                String nombre = Ventana.this.txtNombre.getText();
                float ren = Float.parseFloat(Ventana.this.txtRendimiento.getText());
                String pos = Ventana.this.cboPosicion.getSelectedItem().toString();
                try {
                    //aqui llamo al metodo de editar jugador
                    Ventana.this.eq1.editarJugador(codigo, nombre, ren, pos);
                    //vuelvo a setear la lista de jugadores
                    Ventana.this.txtListado.setText(Ventana.this.eq1.listarTodos());

                    JOptionPane.showMessageDialog((Component)null, "Jugador editado correctamente.");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog((Component)null, ex.getMessage());
                }
            }
        });
    }

    //generar for main

    public static void main(String[] args)
    {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
