import java.util.Stack;

public class Pila {
    //metodos mas importantes de clase pila
    //pop, empty, search
    //principio clase pila, LIFO
    //crear objeto clase Stack o pila

    private Stack<String> coleccion;
    public Pila (){
        //instanciar
        coleccion=new Stack<String>(); //mayor o menos se especifica el tipo de dato que tiene la pila
        //aqui <> especifico que la pila solo va guardar string
    }

    //metodo principal que es el push
     //una variable que tenga el dato
         //aqui va a estar esperandi que le de un dato
    public void push(String dato) throws Exception {
        if (coleccion.size() >= 10) {
            throw new Exception("La pila ha alcanzado su límite máximo de 10 elementos");
        }
        coleccion.push(dato);
    }

    //Metodo
    public String pop() throws Exception{

        if (coleccion.empty()) {
            throw new Exception("Pila vacia");
        }
        return coleccion.pop();
    }


    //Metodo
    public String cima() throws Exception{
      /*  if (colecccion.empty()) {
            throw new Exception("Pila vacia");
        }*/ //deber
        return coleccion.peek();
    }

    //Metodo
    @Override
    public String toString() {

        StringBuilder listado = new  StringBuilder();
        for(int i = coleccion.size()-1;i>=0;i--) {
            listado.append(coleccion.get(i)+"\n");

        }
        return listado.toString();
    }
}
//hacer la busqueda,
//un listado de discos de musica
//Quiero buscar el disco de julio jaramillo
//que me diga desde la cima hay 10 elementos

//completamos la busqueda y la cima

