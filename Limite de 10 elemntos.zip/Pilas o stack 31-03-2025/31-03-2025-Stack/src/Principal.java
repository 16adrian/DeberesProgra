import javax.swing.*;
import java.sql.SQLOutput;

public class Principal {
    //crear nuestro main
    public static void main(String[] args) throws Exception {
        //pbjeto tipo pila, un objeto que se llama data
        Pila data=new Pila();

        //invocar a los metodos
        data.push("elemento 1");
        data.push("elemento 2");
        data.push("elemento 3");
        data.push("elemento 4");
        data.push("elemento 5"); //guardando la informacion
        System.out.println("pila");
        System.out.println(data.toString()); //imprimir los elementos almacenados
        String eliminado=data.pop();
        JOptionPane.showMessageDialog(null, eliminado);
        System.out.println("pila");
        System.out.println(data.toString()); //volvuebdi a imprimir los elementos
        JOptionPane.showMessageDialog(null, "en la cima de la pila esta: "+data.cima());
    }
}
