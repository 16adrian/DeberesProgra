import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextArea txtMostrar;
    private JButton agragarButton;
    private JButton btnPop;
    private JLabel lblTexto;
    private JTextField txtTexto;

    //objeto pila
    private Pila data=new Pila(); //cree un nuevo atributo

    public Ventana() {
        agragarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    data.push(txtTexto.getText());
                    txtMostrar.setText(data.toString());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        btnPop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            try{ //se uso para capturar el error
                String eliminado=data.pop();
                JOptionPane.showMessageDialog(null, "Se eliminado: "+eliminado);
                txtMostrar.setText(data.toString()); //estas lineas componen el boton eliminar
            } catch (Exception ex){
                JOptionPane.showMessageDialog(null, ex.getMessage());}
            }
        });
    }
//la ultima parte generar el formain
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
