import java.util.Stack;
//Autor: Adrian Morales Quilumba

public class Pila {

    //tipos de datos strings
    private Stack<String> pila;

    public Pila(){
        pila=new Stack<String>();
    }

    public void insertar(String dato){
        pila.push(dato);
    }
    public String sacar() throws Exception{ //throws esto para cuando este devolviendo objetos, manejo de excepciones

        if(pila.isEmpty()) //si la pila esta vacia no podemos dolver un objeto tipo string
            throw new Exception("Faltan elementos de apertura"); //salta error porque manejasmo excepciones
        return pila.pop(); //si la pila esta vacia no hay nada que devolver, este string se va hacer null (Esto esta elinando)

    }

    //metodo que permite comprobar si la pila esta vacia
    //metodo publico, devuleva un booleano
    public boolean esVacia(){
        if(pila.isEmpty())
            return true;
        else
            return false; //verificador para las clases externas de la clase pila
    }
}
