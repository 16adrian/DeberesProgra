import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextArea txtCodigo;
    private JButton btnVerificar;

    //estar dentro de la clase para hacer el constructor
    //
    public Ventana() {
        btnVerificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //poner lo siguiente
                try {


                    Pila p1 = new Pila();
                    String codigo = txtCodigo.getText(); //para capturar el texto

                    //recorrer cada uno de los caracteres, del 0 a la cantidad de n elemntos
                    for (int i = 0; i <= codigo.length() - 1; i++)
                    {
                        //voy a scar sel string un caracter
                        char c = codigo.charAt(i); //el chart art necesita un entero
                        if (c == '(' || c == '{' || c ==  '[')
                        {
                            p1.insertar(String.valueOf(c)); //transformamos el el string a char

                        } else
                        {
                            if (c == ')' || c == '}' || c ==  ']'  )
                            {
                                char sale = p1.sacar().charAt(0); //asi saco el primer caracter del string
                                //solo segui la misma logica del cierre de () en tutorias y agregue el resto
                                if(((c == ')') && (sale != '(') || (c == '}') && (sale != '{') || (c == ']') && (sale != '['))

                                )
                                {
                                    JOptionPane.showMessageDialog(null, "mo coinciden elementos de cierre y apertura");
                                    //para que no siga continuando le doy return
                                    return;
                                }
                            }
                        }
                    }
                    //comprobar
                    if(p1.esVacia()){
                        JOptionPane.showMessageDialog(null,"codigo correcto");
                    }else {
                        JOptionPane.showMessageDialog(null, "Codigo incorrecto, faltan elementos de cierre");
                    }

                } catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }

        }); //dentro del constructor se genera el codigo del boton.

    }

    //salimos del constructor
    //generar formaain
    //crea un objeto par apoder ejecutar el formain
    public static void main(String[] args) { //crea un objeto tipo ventana
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
