public class Auto {
    //2 atributos
    //Autor: Adrián Morales Quilumba
    private String marca;
    private int anio;
    //genero una variable privada con un valor fijo para el calculo del auto
    private int aActual=2025;

    //generar constructor
    public Auto(String marca, int anio) {
        this.marca = marca;
        this.anio = anio;
    }
    //generar getters y setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    //sobreescritura del to string
    //metodo para calcular el pago
    public double calcularPago() {
        return (this.aActual-this.anio)*50;
    }


    @Override
    //concatenando strings
    public String toString() {
        return "\n---Auto---\n" + "Marca: "+marca + "\t Año: "+anio + "\tPago total de impuesto: $" + calcularPago();
    }
}

