import java.util.LinkedList;
import java.util.Queue;

public class ColaAutos {

    //declaracion del queue o cola
    private Queue<Auto> listaAutos; //le guarde en <> el tipo de dato quie quiero que guarde

    //constructor hecho con linked list
    public ColaAutos(){
        listaAutos = new LinkedList<Auto>();
    }

    //metodo encolar y desencolar

    //podemos pasar de un objeto
    public void encolar(Auto dato){
        listaAutos.add(dato); //insertar en el primer elemento un auto

    }

    //metodo desencolar
    //devuelvo una clase/ objeto
    //thorws Exception para manejo de errores
    public Auto desencolar() throws Exception{
        if(listaAutos.isEmpty())
            throw new Exception("Ya no existen autos encolados");
        return  listaAutos.poll();
    }

    //metodo peek
    //devuelvo una clase/ objeto
    //thorws Exception para manejo de errores
    public Auto frente() throws Exception{
        if(listaAutos.isEmpty())
            throw new Exception("Ya no existen autos encolados");
        return  listaAutos.peek(); //muestra el inicio pero no lo elimina
    }

    //metodo listar todos los elementos
    public String listarTodos(){
        //crear string builder
        StringBuilder sb=new StringBuilder();
        //como reccrrer si no es indexable
        //ocupar el for mejorado
        //necesitamos 1 variable del tipo de dato que almacena la coleccion
        for (Auto a1:listaAutos){
            //este for sabe automaticamente cuantos elementos existen dentro de la listaAuto
            //recorre 1 por 1 hasta leer los elementos de la collecion

            sb.append(a1.toString());
        }
        return sb.toString(); //es un objeto sb, para hacerle string necesito hacerle tostring
    }
}

