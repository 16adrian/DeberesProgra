import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JComboBox cboMarca;
    private JTextField txtAnio;
    private JButton btnEncolar;
    private JButton btnDesencolar;
    private JTextArea txtListado;
    private JLabel lblPago;
    private ColaAutos autos=new ColaAutos();

    public Ventana() {

        btnEncolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //vamos a capturar la informacion
                //metodo para capturar lo que selecciono en el combobox
                String marca = cboMarca.getSelectedItem().toString();

                //todo lo que capture en el el entero anio lo transformo a texto//
                int anio=Integer.parseInt(txtAnio.getText());
                autos.encolar(new Auto(marca, anio)); //crear objeto para encolar

                //ya que se muestre en el txt area
                txtListado.setText(autos.listarTodos());
            }
        });
        //proceso de desencolar
        btnDesencolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Auto atendido = autos.desencolar();
                    lblPago.setText("Ultimo auto atendido: "+atendido.toString());
                    txtListado.setText(autos.listarTodos());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 800);
        //frame.pack();
        frame.setVisible(true);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}

//Deber por cada año que el auto tenga, pagar 50$, hacer una multiplicacion del año del carro
//info sale del ultimo año atendido
